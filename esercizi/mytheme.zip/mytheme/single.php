<?php get_header(); ?>

<main>
    <?php the_post_thumbnail(); ?>

    <h1><?php the_title(); ?></h1>
    <div class="date"><?php the_modified_date(); ?></div>
    <div class="time"><?php the_time(); ?></div>
    <div class="excerpt"><?php the_excerpt(); ?></div>
    <div class="content"><?php the_content(); ?></div>
</main>

<?php get_footer(); ?>