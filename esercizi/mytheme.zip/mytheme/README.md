# mytheme

## Funzioni

### get_header
Include l'header del tema.

    <?php get_header(); ?>

### get_footer
Include il footer del tema.

    <?php get_footer(); ?>

### wp_nav_menu
Include il menu nella posizione indicata.

    <?php wp_nav_menu([
        'theme_location' => 'principale',
    ]); ?>

Le possibili posizioni configurate nel tema sono:
* principale
* secondario
* social
* footer

### the_title
Titolo del post/della pagina.

    <h1><?php the_title(); ?></h1>

### the_excerpt
Riassunto del post/della pagina.

    <div class="excerpt"><?php the_excerpt(); ?></div>

### the_modified_date
Data di pubblicazione del post utilizzando il formato definito nelle impostazioni.

    <div class="date"><?php the_modified_date(); ?></div>

### the_time
Ora di pubblicazione del post utilizzando il formato definito nelle impostazioni.

    <div class="time"><?php the_time(); ?></div>

### the_content
Contenuto del post/della pagina.

    <div class="content"><?php the_content(); ?></div>

### the_permalink
Link al post/alla pagina, restituisce solo l'URL completo.

    <a href="<?php the_permalink() ?>">Vai al post</a>

### the_post_thumbnail
Immagine del post/della pagina come codice HTML, tag `<img/>` con tutti gli attributi.

    <?php the_post_thumbnail(); ?>

### the_posts
Funzione personalizzata per selezionare e mostrare post dinamicamente utilizzando dei file "loop template".

    <?php the_posts(
        ['posts_per_page' => 6],
        'templates/loop-item.php',
        'templates/loop-notfound.php'
    ); ?>

## Query

L'esempio mostra i 3 post più recenti, ordinati dal più recente al più vecchio. Il file `templates/loop-item.php` viene ripetuto per tutti i post trovati, se non vengono trovati risultati viene incluso il file `templates/loop-notfound.php`.

    <?php the_posts(
        ['posts_per_page' => 3, 'orderby' => 'date', 'order' => 'desc'],
        'templates/loop-item.php',
        'templates/loop-notfound.php'
    ); ?>

### Selezione ultimi N post
Rimpiazza `3` con il numero desiderato di post.

    <?php the_posts(
        ['posts_per_page' => 3],
        ...
    ) ?>

### Selezione tutti i post di una categoria
Rimpiazza `eventi` con lo slug della categoria.

    <?php the_posts(
        ['category_name' => 'eventi', 'posts_per_page' => -1],
        ...
    ) ?>

### Selezione i post recenti di un tag
Rimpiazza `report` con lo slug del tag e `10` con il numero di post necessari.

    <?php the_posts(
        ['tag' => 'report', 'posts_per_page' => 10],
        ...
    ) ?>

### Selezione i post recenti ordinati per titolo
Rimpiazza `5` con il numero di post necessari.

    <?php the_posts(
        ['posts_per_page' => 5, 'orderby' => 'title', 'order' => 'asc'],
        ...
    ) ?>