<?php get_header(); the_post(); ?>

<main>
    <?php the_post_thumbnail(); ?>

    <h1><?php the_title(); ?></h1>
    <div class="excerpt"><?php the_excerpt(); ?></div>
    <div class="content"><?php the_content(); ?></div>
</main>

<?php get_footer(); ?>