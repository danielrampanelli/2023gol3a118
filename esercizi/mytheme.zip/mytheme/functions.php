<?php

add_action('after_setup_theme', function() {
    // abilita il supporto per menu
    add_theme_support('menus');

    // abilita il supporto per l'immagine in evidenza per post/pagine
    add_theme_support('post-thumbnails');

    // stili di default di wordpress
    add_theme_support('wp-block-styles');

    // definisci i vari menu che il tema supporta
    register_nav_menus([
        'principale' => 'Principale',
        'secondario' => 'Secondario',
        'social' => 'Social',
        'footer' => 'Footer',
    ]);
});

function the_posts($queryString, $itemTemplate, $placeholderTemplate = '') {
    query_posts($queryString);

    if (have_posts()) {
        while (have_posts()) {
            the_post();

            if (file_exists(__DIR__.'/'.$itemTemplate)) {
                include(__DIR__.'/'.$itemTemplate);
            }
        }
    } else {
        if (!empty($placeholderTemplate) && file_exists(__DIR__.'/'.$placeholderTemplate)) {
            include(__DIR__.'/'.$placeholderTemplate);
        }
    }

    wp_reset_query();
}